using RimWorld;
using Verse;

namespace StorageSelector
{
    [DefOf]
    public static class JobDefOf
    {
        public static JobDef StorageHaul;

        static JobDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(JobDefOf));
        }
    }
}
