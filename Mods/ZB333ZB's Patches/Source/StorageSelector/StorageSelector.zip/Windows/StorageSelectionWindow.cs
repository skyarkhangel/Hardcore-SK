using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using LWM.DeepStorage;

namespace StorageSelector.Windows
{
    public class StorageSelectionWindow : Window
    {
        private readonly Bill bill;
        private readonly bool isInput;
        private readonly Action<Building_Storage> onStorageSelected;
        private readonly List<Building_Storage> availableStorages;
        private readonly List<Zone_Stockpile> availableStockpiles;
        private readonly bool isStockpileMode;
        private string searchText = "";
        private Vector2 scrollPosition = Vector2.zero;
        private float viewHeight;

        public StorageSelectionWindow(Bill bill, bool isInput, Action<Building_Storage> onStorageSelected, List<Zone_Stockpile> stockpiles = null)
        {
            this.bill = bill;
            this.isInput = isInput;
            this.onStorageSelected = onStorageSelected;
            isStockpileMode = stockpiles != null;

            closeOnClickedOutside = true;
            doCloseX = true;
            absorbInputAroundWindow = true;
            forcePause = true;
            draggable = true;
            resizeable = true;

            if (isStockpileMode)
            {
                availableStockpiles = stockpiles ?? new List<Zone_Stockpile>();
                availableStorages = new List<Building_Storage>();
            }
            else
            {
                availableStockpiles = new List<Zone_Stockpile>();
                availableStorages = new List<Building_Storage>();

                var allBuildings = bill.Map.listerBuildings.allBuildingsColonist;
                foreach (var building in allBuildings)
                {
                    if (building is Building_Storage storage)
                    {
                        var deepStorage = storage.TryGetComp<CompDeepStorage>();
                        if (deepStorage != null)
                        {
                            availableStorages.Add(storage);
                            continue;
                        }

                        if (storage.def.building.preventDeteriorationInside)
                        {
                            availableStorages.Add(storage);
                        }
                    }
                }
            }

            windowRect = new Rect((UI.screenWidth - 700f) / 2f, (UI.screenHeight - 700f) / 2f, 700f, 700f);
        }

        private string GetStockpileTooltip(Zone_Stockpile stockpile)
        {
            if (stockpile == null) return "";

            var storedItems = new Dictionary<string, int>();
            foreach (var cell in stockpile.Cells)
            {
                foreach (var thing in stockpile.Map.thingGrid.ThingsListAtFast(cell))
                {
                    if (thing.def.category == ThingCategory.Item)
                    {
                        var label = thing.def.label;
                        if (!storedItems.ContainsKey(label))
                        {
                            storedItems[label] = 0;
                        }
                        storedItems[label] += thing.stackCount;
                    }
                }
            }

            var tooltip = $"{stockpile.label}\n" +
                         $"{"ZB333ZB.StorageSelector.Cells".Translate()}: {stockpile.Cells.Count()}\n\n" +
                         "ZB333ZB.StorageSelector.StoredItems".Translate() + ":";

            if (!storedItems.Any())
            {
                tooltip += $"\n  - {"ZB333ZB.StorageSelector.Nothing".Translate()}";
            }
            else
            {
                tooltip += "\n" + string.Join("\n", storedItems
                    .OrderBy(kv => kv.Key)
                    .Select(kv => $"  - {kv.Key} (x{kv.Value})"));
            }

            return tooltip;
        }

        public override void DoWindowContents(Rect inRect)
        {
            var titleRect = new Rect(inRect.x, inRect.y, inRect.width, 35f);
            Text.Font = GameFont.Medium;
            Widgets.Label(titleRect, isStockpileMode ?
                "ZB333ZB.StorageSelector.SelectStockpile".Translate() :
                "ZB333ZB.StorageSelector.SelectStorage".Translate());
            Text.Font = GameFont.Small;

            var searchRect = new Rect(inRect.x, titleRect.yMax + 5f, inRect.width, 30f);
            searchText = Widgets.TextField(searchRect, searchText);

            var listingRect = new Rect(inRect.x, searchRect.yMax + 5f, inRect.width, inRect.height - searchRect.yMax - 5f - 35f);
            var viewRect = new Rect(0f, 0f, listingRect.width - 16f, viewHeight);

            Widgets.BeginScrollView(listingRect, ref scrollPosition, viewRect);
            try
            {
                float curY = 0f;

                if (isStockpileMode)
                {
                    var filteredStockpiles = availableStockpiles
                        .Where(s => string.IsNullOrEmpty(searchText) ||
                                  s.label.ToLower().Contains(searchText.ToLower()));

                    if (!filteredStockpiles.Any())
                    {
                        var noResultsRect = new Rect(0f, curY, viewRect.width, 30f);
                        Widgets.Label(noResultsRect, "ZB333ZB.StorageSelector.NoStockpilesFound".Translate());
                        curY += 32f;
                    }
                    else
                    {
                        foreach (var stockpile in filteredStockpiles)
                        {
                            var rowRect = new Rect(0f, curY, viewRect.width, 30f);
                            if (rowRect.y + rowRect.height >= scrollPosition.y && rowRect.y <= scrollPosition.y + listingRect.height)
                            {
                                if (Widgets.ButtonText(rowRect, stockpile.label))
                                {
                                    bill.SetStoreMode(BillStoreModeDefOf.SpecificStockpile, stockpile);
                                    Close();
                                }

                                if (Mouse.IsOver(rowRect))
                                {
                                    Widgets.DrawHighlight(rowRect);
                                    TooltipHandler.TipRegion(rowRect, GetStockpileTooltip(stockpile));
                                }
                            }
                            curY += 32f;
                        }
                    }
                }
                else
                {
                    var filteredStorages = availableStorages
                        .Where(s => string.IsNullOrEmpty(searchText) ||
                                  StorageUtility.GetStorageLabel(s).ToLower().Contains(searchText.ToLower()));

                    if (!filteredStorages.Any())
                    {
                        var noResultsRect = new Rect(0f, curY, viewRect.width, 30f);
                        Widgets.Label(noResultsRect, "ZB333ZB.StorageSelector.NoStoragesFound".Translate());
                        curY += 32f;
                    }
                    else
                    {
                        foreach (var storage in filteredStorages)
                        {
                            var rowRect = new Rect(0f, curY, viewRect.width, 30f);
                            if (rowRect.y + rowRect.height >= scrollPosition.y && rowRect.y <= scrollPosition.y + listingRect.height)
                            {
                                if (Widgets.ButtonText(rowRect, StorageUtility.GetStorageLabel(storage)))
                                {
                                    onStorageSelected(storage);
                                    Close();
                                }

                                if (Mouse.IsOver(rowRect))
                                {
                                    Widgets.DrawHighlight(rowRect);
                                    TooltipHandler.TipRegion(rowRect, StorageUtility.GetStorageTooltip(storage));
                                }
                            }
                            curY += 32f;
                        }
                    }
                }
                viewHeight = curY;
            }
            finally
            {
                Widgets.EndScrollView();
            }
        }
    }
}
