using RimWorld;
using Verse;

namespace StorageSelector
{
    public static class StorageMessages
    {
        private static string GetStorageTypeKey(IStoreSettingsParent storage)
        {
            return storage is Zone_Stockpile
                ? "ZB333ZB.StorageSelector.Stockpile".Translate()
                : "ZB333ZB.StorageSelector.Storage".Translate();
        }

        private static string GetStorageLabel(IStoreSettingsParent storage)
        {
            if (storage is Zone_Stockpile stockpile)
                return stockpile.label;
            if (storage is Building_Storage building)
                return StorageUtility.GetStorageLabel(building);
            return "Unknown";
        }

        public static void ShowStorageFullMessage(IStoreSettingsParent storage)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.IsFull".Translate(
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage)),
                storage is Thing thing ? thing : null,
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowStorageDisallowedMessage(IStoreSettingsParent storage, Thing thing)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.NotAllowed".Translate(
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage),
                    thing.Label),
                storage is Thing t ? t : null,
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowStorageUnreachableMessage(IStoreSettingsParent storage)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.Unreachable".Translate(
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage)),
                storage is Thing thing ? thing : null,
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowStorageNearlyFullMessage(IStoreSettingsParent storage, float percentRemaining)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.NearlyFull".Translate(
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage),
                    percentRemaining.ToString("F0")),
                storage is Thing thing ? thing : null,
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowProductsCreatedMessage(int count, IStoreSettingsParent storage)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.ProductsCreated".Translate(
                    count,
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage)),
                storage is Thing thing ? thing : null,
                MessageTypeDefOf.TaskCompletion);
        }

        public static void ShowStorageInvalidMessage(string billLabel, bool isInput, IStoreSettingsParent storage)
        {
            Messages.Message(
                (isInput ? "ZB333ZB.StorageSelector.InputInvalid" : "ZB333ZB.StorageSelector.OutputInvalid")
                    .Translate(
                        GetStorageTypeKey(storage),
                        billLabel),
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowCheckStorageSettingsMessage(IStoreSettingsParent storage)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.CheckSettings".Translate(
                    GetStorageTypeKey(storage),
                    GetStorageLabel(storage)),
                storage is Thing thing ? thing : null,
                MessageTypeDefOf.CautionInput);
        }

        public static void ShowStorageClearedMessage(string billLabel, IStoreSettingsParent storage)
        {
            Messages.Message(
                "ZB333ZB.StorageSelector.Cleared".Translate(
                    GetStorageTypeKey(storage),
                    billLabel),
                MessageTypeDefOf.SilentInput);
        }

        public static void ShowStorageStatusMessage(IStoreSettingsParent storage, int usedStacks, int maxStacks)
        {
            if (maxStacks == 0)
            {
                Messages.Message(
                    "ZB333ZB.StorageSelector.Empty".Translate(
                        GetStorageTypeKey(storage),
                        GetStorageLabel(storage)),
                    storage is Thing thing ? thing : null,
                    MessageTypeDefOf.SilentInput);
            }
            else if (usedStacks >= maxStacks)
            {
                Messages.Message(
                    "ZB333ZB.StorageSelector.Full".Translate(
                        GetStorageTypeKey(storage),
                        GetStorageLabel(storage)),
                    storage is Thing thing ? thing : null,
                    MessageTypeDefOf.CautionInput);
            }
            else if (usedStacks >= maxStacks * 0.9f)
            {
                Messages.Message(
                    "ZB333ZB.StorageSelector.AlmostFull".Translate(
                        GetStorageTypeKey(storage),
                        GetStorageLabel(storage)),
                    storage is Thing thing ? thing : null,
                    MessageTypeDefOf.CautionInput);
            }
            else
            {
                Messages.Message(
                    "ZB333ZB.StorageSelector.Status".Translate(
                        GetStorageTypeKey(storage),
                        GetStorageLabel(storage),
                        usedStacks,
                        maxStacks),
                    storage is Thing thing ? thing : null,
                    MessageTypeDefOf.SilentInput);
            }
        }
    }
}
