using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace StorageSelector.Patches
{
    [HarmonyPatch]
    public static class BillWorker_Patches
    {
        [HarmonyPatch(typeof(WorkGiver_DoBill))]
        [HarmonyPatch("TryFindBestBillIngredientsInSet")]
        public static class TryFindBestBillIngredients_Patch
        {
            public static void Prefix(List<Thing> availableThings, Bill bill)
            {
                try
                {
                    if (bill == null || availableThings == null) return;

                    var storage = ExtendedBillDataStorage.GetStorage();
                    if (storage == null) return;

                    var inputStorage = storage.GetInputStorage(bill);
                    if (inputStorage == null || !StorageUtility.IsValidStorageBuilding(inputStorage))
                        return;

                    var validCells = new HashSet<IntVec3>(inputStorage.GetSlotGroup()?.CellsList ?? new List<IntVec3>());
                    availableThings.RemoveAll(t => !validCells.Contains(t.Position));
                }
                catch (Exception e)
                {
                    Log.Error($"[StorageSelector] Error in TryFindBestBillIngredients Prefix: {e}");
                }
            }
        }

        [HarmonyPatch(typeof(Toils_Recipe))]
        [HarmonyPatch("FinishRecipeAndStartStoringProduct")]
        public static class FinishRecipeAndStartStoringProduct_Patch
        {
            public static void Postfix(Toil __instance)
            {
                try
                {
                    var job = __instance?.actor?.CurJob;
                    if (job?.bill == null) return;

                    var storage = ExtendedBillDataStorage.GetStorage();
                    if (storage == null) return;

                    // Получаем целевое хранилище (наше storage или vanilla stockpile)
                    IStoreSettingsParent targetStorage = null;
                    var outputStorage = storage.GetOutputStorage(job.bill);
                    if (outputStorage != null && StorageUtility.IsValidStorageBuilding(outputStorage))
                    {
                        targetStorage = outputStorage;
                    }
                    else if (job.bill is Bill_Production billProd)
                    {
                        var storeMode = billProd.GetStoreMode();
                        if (storeMode == BillStoreModeDefOf.SpecificStockpile)
                        {
                            targetStorage = billProd.GetStoreZone();
                        }
                    }

                    if (targetStorage == null) return;

                    // Get the workbench position where items will be created
                    var workTable = job.GetTarget(TargetIndex.A).Thing as Building_WorkTable;
                    if (workTable == null) return;

                    // Find all products at the workbench position
                    var products = workTable.Map.thingGrid.ThingsListAt(workTable.Position)
                        .Where(t => t.def == job.bill.recipe.ProducedThingDef)
                        .ToList();

                    if (!products.Any())
                    {
                        Log.Warning($"[StorageSelector] No products found at workbench position after bill completion.");
                        return;
                    }

                    // Check if storage is reachable
                    if (targetStorage is Thing storeThing &&
                        !__instance.actor.Map.reachability.CanReach(workTable.Position, storeThing,
                            PathEndMode.Touch, TraverseParms.For(__instance.actor)))
                    {
                        StorageMessages.ShowStorageUnreachableMessage(targetStorage);
                        return;
                    }

                    var successfulHauls = 0;
                    foreach (var product in products)
                    {
                        string errorMessage;
                        if (!StorageUtility.CanAcceptThing(targetStorage, product, out errorMessage))
                        {
                            switch (errorMessage)
                            {
                                case "StorageFull":
                                    StorageMessages.ShowStorageFullMessage(targetStorage);
                                    break;
                                case "StorageNotAllowed":
                                    StorageMessages.ShowStorageDisallowedMessage(targetStorage, product);
                                    break;
                                case "StorageNearlyFull":
                                    var maxStacks = StorageUtility.GetMaxStacks(targetStorage);
                                    var usedStacks = StorageUtility.GetUsedStacks(targetStorage);
                                    var percentRemaining = ((maxStacks - usedStacks) / (float)maxStacks) * 100f;
                                    StorageMessages.ShowStorageNearlyFullMessage(targetStorage, percentRemaining);
                                    break;
                            }
                            continue;
                        }

                        // Create haul job if it's our storage
                        if (targetStorage is Building_Storage buildingStorage)
                        {
                            var haulJob = JobMaker.MakeJob(JobDefOf.StorageHaul, product, buildingStorage);
                            __instance.actor.jobs.StartJob(haulJob, JobCondition.InterruptForced);
                            successfulHauls++;
                        }
                    }

                    if (successfulHauls > 0)
                    {
                        StorageMessages.ShowProductsCreatedMessage(successfulHauls, targetStorage);
                    }
                }
                catch (Exception e)
                {
                    Log.Error($"[StorageSelector] Error in FinishRecipeAndStartStoringProduct Postfix: {e}");
                }
            }
        }

        [HarmonyPatch(typeof(Bill))]
        [HarmonyPatch(nameof(Bill.Notify_BillWorkStarted))]
        public static class Bill_WorkStarted_Patch
        {
            public static void Prefix(Bill __instance, Pawn billDoer)
            {
                try
                {
                    var storage = ExtendedBillDataStorage.GetStorage();
                    if (storage == null) return;

                    // Validate input storage at work start
                    var inputStorage = storage.GetInputStorage(__instance);
                    if (inputStorage != null)
                    {
                        if (!StorageUtility.IsValidStorageBuilding(inputStorage))
                        {
                            storage.SetInputStorage(__instance, null);
                            StorageMessages.ShowStorageInvalidMessage(__instance.Label, true, inputStorage);
                        }
                        else if (!billDoer.Map.reachability.CanReach(billDoer.Position, inputStorage, PathEndMode.Touch,
                            TraverseParms.For(billDoer)))
                        {
                            StorageMessages.ShowStorageUnreachableMessage(inputStorage);
                        }
                    }

                    // Validate output storage at work start
                    var outputStorage = storage.GetOutputStorage(__instance);
                    if (outputStorage != null)
                    {
                        if (!StorageUtility.IsValidStorageBuilding(outputStorage))
                        {
                            storage.SetOutputStorage(__instance, null);
                            StorageMessages.ShowStorageInvalidMessage(__instance.Label, false, outputStorage);
                        }
                        else
                        {
                            // Check storage settings
                            var recipe = __instance as Bill_Production;
                            if (recipe != null && recipe.recipe.ProducedThingDef != null)
                            {
                                if (!outputStorage.GetSlotGroup()?.Settings?.AllowedToAccept(recipe.recipe.ProducedThingDef) ?? false)
                                {
                                    StorageMessages.ShowCheckStorageSettingsMessage(outputStorage);
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Log.Error($"[StorageSelector] Error in Bill_WorkStarted Prefix: {e}");
                }
            }
        }
    }
}
