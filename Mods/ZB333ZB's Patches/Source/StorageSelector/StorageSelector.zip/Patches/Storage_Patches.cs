using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace StorageSelector.Patches
{
    [HarmonyPatch]
    public static class Storage_Patches
    {
        [HarmonyPatch(typeof(Building), nameof(Building.DeSpawn))]
        public static class Building_DeSpawn_Patch
        {
            public static void Prefix(Building __instance)
            {
                if (__instance is Building_Storage)
                {
                    StorageUtility.UpdateBillStorageReferences();
                }
            }
        }

        [HarmonyPatch(typeof(Building), nameof(Building.Destroy))]
        public static class Building_Destroy_Patch
        {
            public static void Prefix(Building __instance)
            {
                if (__instance is Building_Storage)
                {
                    StorageUtility.UpdateBillStorageReferences();
                }
            }
        }

        [HarmonyPatch]
        public static class DeepStorage_Patches
        {
            private static readonly Type CompDeepStorageType = AccessTools.TypeByName("LWM.DeepStorage.CompDeepStorage");
            private static readonly Type IHoldMultipleThingsType = AccessTools.TypeByName("LWM.DeepStorage.IHoldMultipleThings");

            public static bool Prepare()
            {
                return CompDeepStorageType != null && IHoldMultipleThingsType != null;
            }

            public static MethodBase TargetMethod()
            {
                return CompDeepStorageType?.GetMethod("PostDeSpawn") ?? null;
            }

            public static void Prefix()
            {
                StorageUtility.UpdateBillStorageReferences();
            }
        }
    }
}
