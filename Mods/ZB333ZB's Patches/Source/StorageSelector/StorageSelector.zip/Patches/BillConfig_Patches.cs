using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;
using StorageSelector.Windows;

namespace StorageSelector.Patches
{
    [HarmonyPatch]
    public static class BillConfig_Patches
    {
        private static readonly FieldInfo BillGetter = AccessTools.Field(typeof(Dialog_BillConfig), "bill");
        private static readonly FieldInfo StoreZoneField = AccessTools.Field(typeof(Bill_Production), "storeZone");
        private static readonly FieldInfo RepeatCountBufferField = AccessTools.Field(typeof(Dialog_BillConfig), "repeatCountEditBuffer");
        private static readonly FieldInfo TargetCountBufferField = AccessTools.Field(typeof(Dialog_BillConfig), "targetCountEditBuffer");
        private static readonly FieldInfo UnpauseCountBufferField = AccessTools.Field(typeof(Dialog_BillConfig), "unpauseCountEditBuffer");
        private static readonly MethodInfo DoIngredientConfigPaneMethod = AccessTools.Method(typeof(Dialog_BillConfig), "DoIngredientConfigPane");

        private const float RepeatModeHeight = 200f;
        private const float StorageModeHeight = 70f;
        private const float WorkerSelectionHeight = 85f;
        private const float SectionGapBefore = 4f;
        private const float SectionGapAfter = 4f;
        private const float SectionGap = 12f;

        [HarmonyPatch(typeof(Bill_Production), "SetStoreMode")]
        public static class SetStoreMode_Patch
        {
            public static void Prefix(Bill_Production __instance, BillStoreModeDef mode, Zone_Stockpile zone)
            {
                try
                {
                    var storage = ExtendedBillDataStorage.GetStorage();
                    if (storage == null) return;

                    if (mode != null || zone != null)
                    {
                        var currentStorage = storage.GetOutputStorage(__instance);
                        if (currentStorage != null)
                        {
                            storage.SetOutputStorage(__instance, null);
                            Messages.Message("ZB333ZB.StorageSelector.StorageCleared".Translate(__instance.Label),
                                MessageTypeDefOf.SilentInput);
                        }
                    }
                }
                catch (Exception e)
                {
                    Log.Error($"[StorageSelector] Error in SetStoreMode Prefix: {e}");
                }
            }
        }

        [HarmonyPatch(typeof(Dialog_BillConfig))]
        [HarmonyPatch("DoWindowContents")]
        public static class DoWindowContents_Patch
        {
            public static bool Prefix(Dialog_BillConfig __instance, Rect inRect)
            {
                try
                {
                    if (BillGetter.GetValue(__instance) is not Bill_Production bill) return true;

                    var repeatCountBuffer = (string)RepeatCountBufferField.GetValue(__instance);
                    var targetCountBuffer = (string)TargetCountBufferField.GetValue(__instance);
                    var unpauseCountBuffer = (string)UnpauseCountBufferField.GetValue(__instance);

                    Text.Font = GameFont.Medium;
                    Widgets.Label(new Rect(40f, 0f, 400f, 34f), bill.LabelCap);
                    Text.Font = GameFont.Small;

                    float width = (inRect.width - 34f) / 3f;
                    Rect rect = new(0f, 80f, width, inRect.height - 80f);
                    Rect rect1 = new(rect.xMax + 17f, 50f, width, inRect.height - 50f - Window.CloseButSize.y);
                    Rect rect2 = new(rect1.xMax + 17f, 50f, width, inRect.height - 50f - Window.CloseButSize.y)
                    {
                        xMax = inRect.xMax
                    };

                    var listingStandard4 = new Listing_Standard();
                    listingStandard4.Begin(rect);

                    if (bill.suspended)
                    {
                        if (listingStandard4.ButtonText("Suspended".Translate()))
                        {
                            bill.suspended = false;
                            SoundDefOf.Click.PlayOneShot(SoundInfo.OnCamera());
                        }
                    }
                    else if (listingStandard4.ButtonText("NotSuspended".Translate()))
                    {
                        bill.suspended = true;
                        SoundDefOf.Click.PlayOneShot(SoundInfo.OnCamera());
                    }

                    var stringBuilder = new StringBuilder();
                    if (bill.recipe.description != null)
                    {
                        stringBuilder.AppendLine(bill.recipe.description);
                        stringBuilder.AppendLine();
                    }

                    stringBuilder.AppendLine("WorkAmount".Translate() + ": " + bill.recipe.WorkAmountTotal(null).ToStringWorkAmount());

                    if (ModsConfig.BiotechActive && bill.recipe.products.Count == 1)
                    {
                        var product = bill.recipe.products[0].thingDef;
                        if (product.IsApparel)
                        {
                            stringBuilder.AppendLine("WearableBy".Translate() + ": " + product.apparel.developmentalStageFilter.ToCommaList(false).CapitalizeFirst());
                        }
                    }

                    stringBuilder.AppendLine("BillRequires".Translate() + ": ");
                    for (int i = 0; i < bill.recipe.ingredients.Count; i++)
                    {
                        var ingredient = bill.recipe.ingredients[i];
                        if (!ingredient.filter.Summary.NullOrEmpty())
                        {
                            stringBuilder.AppendLine(" - " + bill.recipe.IngredientValueGetter.BillRequirementsDescription(bill.recipe, ingredient));
                        }
                    }

                    stringBuilder.AppendLine();
                    string extraDesc = bill.recipe.IngredientValueGetter.ExtraDescriptionLine(bill.recipe);
                    if (extraDesc != null)
                    {
                        stringBuilder.AppendLine(extraDesc);
                        stringBuilder.AppendLine();
                    }

                    if (!bill.recipe.skillRequirements.NullOrEmpty())
                    {
                        stringBuilder.AppendLine("MinimumSkills".Translate());
                        stringBuilder.AppendLine(bill.recipe.MinSkillString);
                    }

                    Text.Font = GameFont.Small;
                    string desc = stringBuilder.ToString();
                    if (Text.CalcHeight(desc, rect.width) > rect.height)
                    {
                        Text.Font = GameFont.Tiny;
                    }
                    listingStandard4.Label(desc);
                    Text.Font = GameFont.Small;

                    listingStandard4.End();

                    var listingStandard = new Listing_Standard();
                    listingStandard.Begin(rect1);

                    var listingStandard1 = listingStandard.BeginSection(RepeatModeHeight, SectionGapBefore, SectionGapAfter);
                    if (listingStandard1.ButtonText(bill.repeatMode.LabelCap))
                    {
                        BillRepeatModeUtility.MakeConfigFloatMenu(bill);
                    }
                    listingStandard1.Gap(12f);

                    if (bill.repeatMode == BillRepeatModeDefOf.RepeatCount)
                    {
                        listingStandard1.Label("RepeatCount".Translate(bill.repeatCount));
                        listingStandard1.IntEntry(ref bill.repeatCount, ref repeatCountBuffer, 1);
                    }
                    else if (bill.repeatMode == BillRepeatModeDefOf.TargetCount)
                    {
                        string text = "CurrentlyHave".Translate() + ": ";
                        text += bill.recipe.WorkerCounter.CountProducts(bill);
                        text += " / ";
                        text += bill.targetCount >= 999999 ? "Infinite".Translate().ToLower() : bill.targetCount.ToString();
                        string productsDesc = bill.recipe.WorkerCounter.ProductsDescription(bill);
                        if (!productsDesc.NullOrEmpty())
                        {
                            text += "\n" + "CountingProducts".Translate() + ": " + productsDesc.CapitalizeFirst();
                        }
                        listingStandard1.Label(text);
                        int oldCount = bill.targetCount;
                        listingStandard1.IntEntry(ref bill.targetCount, ref targetCountBuffer, bill.recipe.targetCountAdjustment);
                        bill.unpauseWhenYouHave = Mathf.Max(0, bill.unpauseWhenYouHave + (bill.targetCount - oldCount));

                        ThingDef producedThingDef = bill.recipe.ProducedThingDef;
                        if (producedThingDef != null)
                        {
                            if (producedThingDef.IsWeapon || producedThingDef.IsApparel)
                            {
                                listingStandard1.CheckboxLabeled("IncludeEquipped".Translate(), ref bill.includeEquipped);
                            }
                            if (producedThingDef.IsApparel && producedThingDef.apparel.careIfWornByCorpse)
                            {
                                listingStandard1.CheckboxLabeled("IncludeTainted".Translate(), ref bill.includeTainted);
                            }

                            List<ThingDefCountClass> products = bill.recipe.products;
                            if (products.Any(p => p.thingDef.useHitPoints))
                            {
                                Widgets.FloatRange(listingStandard1.GetRect(28f), 975643279, ref bill.hpRange, 0f, 1f, "HitPoints", ToStringStyle.PercentZero);
                                bill.hpRange.min = Mathf.Round(bill.hpRange.min * 100f) / 100f;
                                bill.hpRange.max = Mathf.Round(bill.hpRange.max * 100f) / 100f;
                            }
                            if (producedThingDef.HasComp(typeof(CompQuality)))
                            {
                                Widgets.QualityRange(listingStandard1.GetRect(28f), 1098906561, ref bill.qualityRange);
                            }
                            if (producedThingDef.MadeFromStuff)
                            {
                                listingStandard1.CheckboxLabeled("LimitToAllowedStuff".Translate(), ref bill.limitToAllowedStuff);
                            }
                        }
                    }

                    if (bill.repeatMode == BillRepeatModeDefOf.TargetCount)
                    {
                        listingStandard1.CheckboxLabeled("PauseWhenSatisfied".Translate(), ref bill.pauseWhenSatisfied);
                        if (bill.pauseWhenSatisfied)
                        {
                            listingStandard1.Label("UnpauseWhenYouHave".Translate() + ": " + bill.unpauseWhenYouHave.ToString("F0"));
                            listingStandard1.IntEntry(ref bill.unpauseWhenYouHave, ref unpauseCountBuffer, bill.recipe.targetCountAdjustment);
                            if (bill.unpauseWhenYouHave >= bill.targetCount)
                            {
                                bill.unpauseWhenYouHave = bill.targetCount - 1;
                                unpauseCountBuffer = bill.unpauseWhenYouHave.ToString();
                            }
                        }
                    }
                    listingStandard.EndSection(listingStandard1);

                    listingStandard.Gap(SectionGap);

                    var listingStandard2 = listingStandard.BeginSection(StorageModeHeight, SectionGapBefore, SectionGapAfter);

                    var storage = ExtendedBillDataStorage.GetStorage();
                    if (storage != null)
                    {
                        var inputStorage = storage.GetInputStorage(bill);
                        var outputStorage = storage.GetOutputStorage(bill);

                        if (listingStandard2.ButtonText(GetInputStorageButtonText(bill, inputStorage)))
                        {
                            var floatMenu = new List<FloatMenuOption>
                            {
                                new("TakeFromAnyStorage".Translate(), () =>
                                {
                                    StoreZoneField?.SetValue(bill, null);
                                    storage.SetInputStorage(bill, null);
                                })
                            };

                            var storages = bill.Map.listerBuildings.allBuildingsColonist
                                .OfType<Building_Storage>()
                                .Where(StorageUtility.IsValidStorageBuilding)
                                .ToList();

                            if (storages.Any())
                            {
                                floatMenu.Add(new FloatMenuOption("ZB333ZB.StorageSelector.Storages".Translate(), () =>
                                {
                                    Find.WindowStack.Add(new StorageSelectionWindow(bill, true, storage =>
                                    {
                                        StoreZoneField?.SetValue(bill, null);
                                        ExtendedBillDataStorage.GetStorage()?.SetInputStorage(bill, storage);
                                    }));
                                }));
                            }

                            var stockpiles = bill.Map.zoneManager.AllZones.OfType<Zone_Stockpile>().ToList();
                            if (stockpiles.Any())
                            {
                                floatMenu.Add(new FloatMenuOption("ZB333ZB.StorageSelector.Stockpiles".Translate(), () =>
                                {
                                    Find.WindowStack.Add(new StorageSelectionWindow(bill, true, null, stockpiles));
                                }));
                            }
                            else
                            {
                                floatMenu.Add(new FloatMenuOption("NoStockpileZones".Translate(), null)
                                {
                                    Disabled = true
                                });
                            }

                            Find.WindowStack.Add(new FloatMenu(floatMenu));
                        }

                        if (listingStandard2.ButtonText(GetOutputStorageButtonText(bill, outputStorage)))
                        {
                            var floatMenu = new List<FloatMenuOption>
                            {
                                new("DropOnFloor".Translate(), () =>
                            {
                                bill.SetStoreMode(BillStoreModeDefOf.DropOnFloor, null);
                                storage.SetOutputStorage(bill, null);
                            }),
                                new("BestStockpile".Translate(), () =>
                                {
                                    bill.SetStoreMode(BillStoreModeDefOf.BestStockpile, null);
                                    storage.SetOutputStorage(bill, null);
                                })
                            };

                            var storages = bill.Map.listerBuildings.allBuildingsColonist
                                .OfType<Building_Storage>()
                                .Where(StorageUtility.IsValidStorageBuilding)
                                .ToList();

                            if (storages.Any())
                            {
                                floatMenu.Add(new FloatMenuOption("ZB333ZB.StorageSelector.Storages".Translate(), () =>
                                {
                                    Find.WindowStack.Add(new StorageSelectionWindow(bill, false, storage =>
                                    {
                                        ExtendedBillDataStorage.GetStorage()?.SetOutputStorage(bill, storage);
                                    }));
                                }));
                            }

                            var stockpiles = bill.Map.zoneManager.AllZones.OfType<Zone_Stockpile>().ToList();
                            if (stockpiles.Any())
                            {
                                floatMenu.Add(new FloatMenuOption("ZB333ZB.StorageSelector.Stockpiles".Translate(), () =>
                                {
                                    Find.WindowStack.Add(new StorageSelectionWindow(bill, false, null, stockpiles));
                                }));
                            }
                            else
                            {
                                floatMenu.Add(new FloatMenuOption("NoStockpileZones".Translate(), null)
                                {
                                    Disabled = true
                                });
                            }

                            Find.WindowStack.Add(new FloatMenu(floatMenu));
                        }
                    }

                    listingStandard.EndSection(listingStandard2);

                    listingStandard.Gap(SectionGap);

                    var listingStandard3 = listingStandard.BeginSection(WorkerSelectionHeight, SectionGapBefore, SectionGapAfter);
                    string workerLabel;
                    if (bill.PawnRestriction != null)
                        workerLabel = bill.PawnRestriction.LabelShortCap;
                    else if (ModsConfig.IdeologyActive && bill.SlavesOnly)
                        workerLabel = "AnySlave".Translate();
                    else if (ModsConfig.BiotechActive && bill.recipe.mechanitorOnlyRecipe)
                        workerLabel = "AnyMechanitor".Translate();
                    else if (!ModsConfig.BiotechActive || !bill.MechsOnly)
                        workerLabel = !ModsConfig.BiotechActive || !bill.NonMechsOnly ? "AnyWorker".Translate() : "AnyNonMech".Translate();
                    else
                        workerLabel = "AnyMech".Translate();

                    if (listingStandard3.ButtonText(workerLabel))
                    {
                        var options = new List<FloatMenuOption>();

                        options.Add(new FloatMenuOption("AnyWorker".Translate(), () => bill.SetAnyPawnRestriction()));

                        if (ModsConfig.IdeologyActive)
                            options.Add(new FloatMenuOption("AnySlave".Translate(), () => bill.SetAnySlaveRestriction()));

                        if (ModsConfig.BiotechActive && bill.recipe.workSkill != null)
                        {
                            if (bill.recipe.mechanitorOnlyRecipe)
                            {
                                var mechanitors = bill.Map.mapPawns.FreeColonists.Where(p => MechanitorUtility.IsMechanitor(p));
                                foreach (var pawn in mechanitors.OrderBy(p => p.LabelShortCap))
                                {
                                    options.Add(new FloatMenuOption(pawn.LabelShortCap, () => bill.SetPawnRestriction(pawn)));
                                }
                            }
                            else
                            {
                                if (MechWorkUtility.AnyWorkMechCouldDo(bill.recipe))
                                {
                                    options.Add(new FloatMenuOption("AnyMech".Translate(), () => bill.SetAnyMechRestriction()));
                                    options.Add(new FloatMenuOption("AnyNonMech".Translate(), () => bill.SetAnyNonMechRestriction()));
                                }

                                var pawns = bill.Map.mapPawns.FreeColonists
                                    .Where(p => p.skills != null && p.skills.GetSkill(bill.recipe.workSkill).Level >= bill.allowedSkillRange.min)
                                    .OrderBy(p => p.LabelShortCap);

                                foreach (var pawn in pawns)
                                {
                                    options.Add(new FloatMenuOption(pawn.LabelShortCap, () => bill.SetPawnRestriction(pawn)));
                                }
                            }
                        }

                        Find.WindowStack.Add(new FloatMenu(options));
                    }

                    if (bill.PawnRestriction == null && bill.recipe.workSkill != null && !bill.MechsOnly)
                    {
                        listingStandard3.Label("AllowedSkillRange".Translate(bill.recipe.workSkill.label));
                        listingStandard3.IntRange(ref bill.allowedSkillRange, 0, 20);
                    }
                    listingStandard.EndSection(listingStandard3);

                    listingStandard.End();

                    float y = rect2.y;
                    DoIngredientConfigPaneMethod.Invoke(__instance, new object[] { rect2.x, y, rect2.width, rect2.height });

                    if (bill.recipe.products.Count == 1)
                    {
                        var product = bill.recipe.products[0].thingDef;
                        Widgets.InfoCardButton(rect.x, rect2.y, product, GenStuff.DefaultStuffFor(product));
                    }

                    return false;
                }
                catch (Exception e)
                {
                    Log.Error($"[StorageSelector] Error in DoWindowContents Prefix: {e}");
                    return true;
                }
            }

            private static string GetInputStorageButtonText(Bill_Production bill, Building_Storage storage)
            {
                if (storage != null)
                    return "ZB333ZB.StorageSelector.TakeFrom".Translate(StorageUtility.GetStorageLabel(storage));

                if (StoreZoneField?.GetValue(bill) is Zone_Stockpile storeZone)
                    return "ZB333ZB.StorageSelector.TakeFrom".Translate(storeZone.label);

                return "TakeFromAnyStorage".Translate();
            }

            private static string GetOutputStorageButtonText(Bill_Production bill, Building_Storage storage)
            {
                if (storage != null)
                    return "ZB333ZB.StorageSelector.TakeTo".Translate(StorageUtility.GetStorageLabel(storage));

                var storeMode = bill.GetStoreMode();
                if (storeMode == BillStoreModeDefOf.DropOnFloor)
                    return "DropOnFloor".Translate();
                if (storeMode == BillStoreModeDefOf.BestStockpile)
                    return "BestStockpile".Translate();

                var storeZone = bill.GetStoreZone();
                if (storeZone != null)
                    return "ZB333ZB.StorageSelector.TakeTo".Translate(storeZone.label);

                return "TakeToStockpile".Translate();
            }
        }
    }
}
