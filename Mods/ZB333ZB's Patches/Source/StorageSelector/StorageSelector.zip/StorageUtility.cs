using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using RimWorld;
using Verse;

namespace StorageSelector
{
    public static class StorageUtility
    {
        public static bool IsValidStorageBuilding(Building_Storage building)
        {
            return building?.def?.thingClass == typeof(Building_Storage) &&
                   building.def.building != null &&
                   building.def.building.fixedStorageSettings != null;
        }

        public static bool IsValidStorage(IStoreSettingsParent storage)
        {
            if (storage == null) return false;

            if (storage is Building_Storage building)
                return IsValidStorageBuilding(building);

            if (storage is Zone_Stockpile zone)
                return zone.Map != null && !zone.Map.zoneManager.AllZones.Contains(zone);

            return false;
        }

        public static string GetStorageLabel(Building_Storage storage)
        {
            if (storage == null) return "";
            return storage.Label ?? storage.def.label;
        }

        public static int GetMaxStacks(IStoreSettingsParent storage)
        {
            try
            {
                if (storage == null) return 0;

                if (storage is Building_Storage building)
                {
                    if (building?.def == null) return 0;

                    var deepStorageComp = building.GetComps<ThingComp>()
                        .FirstOrDefault(c =>
                            c.GetType().FullName.Contains("DeepStorage") ||
                            c.GetType().GetInterfaces().Any(i => i.Name == "IHoldMultipleThings") ||
                            c.GetType().BaseType?.Name == "CompDeepStorage");

                    if (deepStorageComp == null) return 1;

                    var maxStacksField = deepStorageComp.GetType()
                        .GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                        .FirstOrDefault(f => f.Name.Contains("maxNumberStacks"));

                    if (maxStacksField == null) return 1;

                    var maxStacks = maxStacksField.GetValue(deepStorageComp) as int?;
                    if (!maxStacks.HasValue) return 1;

                    var cellCount = building.def.size.x * building.def.size.z;
                    return maxStacks.Value * cellCount;
                }

                if (storage is Zone_Stockpile zone)
                {
                    return zone.cells.Count;
                }

                return 0;
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Error in GetMaxStacks: {e}");
                return 1;
            }
        }

        public static int GetUsedStacks(IStoreSettingsParent storage)
        {
            try
            {
                if (storage == null) return 0;

                if (storage is Building_Storage building)
                {
                    var positions = new List<IntVec3>();
                    var size = building.def.size;
                    var rot = building.Rotation;
                    var basePos = building.Position;

                    for (int x = 0; x < size.x; x++)
                    {
                        for (int z = 0; z < size.z; z++)
                        {
                            var offset = new IntVec3(x, 0, z).RotatedBy(rot);
                            positions.Add(basePos + offset);
                        }
                    }

                    var usedStacks = 0;
                    foreach (var pos in positions)
                    {
                        var thingsAtPos = building.Map.thingGrid.ThingsListAtFast(pos);
                        usedStacks += thingsAtPos.Count(t => t.def.category == ThingCategory.Item);
                    }

                    return usedStacks;
                }

                if (storage is Zone_Stockpile zone)
                {
                    return zone.cells
                        .Sum(cell => zone.Map.thingGrid.ThingsListAtFast(cell)
                            .Count(t => t.def.category == ThingCategory.Item));
                }

                return 0;
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Error in GetUsedStacks: {e}");
                return 0;
            }
        }

        public static bool CanAcceptThing(IStoreSettingsParent storage, Thing thing, out string errorMessage)
        {
            try
            {
                if (storage == null)
                {
                    errorMessage = "InvalidStorage";
                    return false;
                }

                // Проверка настроек хранения
                if (!storage.GetStoreSettings().AllowedToAccept(thing))
                {
                    errorMessage = "StorageNotAllowed";
                    return false;
                }

                // Проверка места
                var maxStacks = GetMaxStacks(storage);
                var usedStacks = GetUsedStacks(storage);

                if (usedStacks >= maxStacks)
                {
                    errorMessage = "StorageFull";
                    return false;
                }

                if (usedStacks >= maxStacks * 0.9f) // 90% заполнено
                {
                    errorMessage = "StorageNearlyFull";
                    return true; // Все еще можно использовать, но с предупреждением
                }

                errorMessage = null;
                return true;
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Error in CanAcceptThing: {e}");
                errorMessage = "Error";
                return false;
            }
        }

        public static string GetStorageTooltip(IStoreSettingsParent storage)
        {
            try
            {
                if (storage == null) return "";

                var maxStacks = GetMaxStacks(storage);
                var usedStacks = GetUsedStacks(storage);

                string storageLabel;
                if (storage is Zone_Stockpile zoneStorage)
                    storageLabel = zoneStorage.label;
                else if (storage is Building_Storage buildingStorage)
                    storageLabel = GetStorageLabel(buildingStorage);
                else
                    storageLabel = "Unknown";

                var tooltip = "ZB333ZB.StorageSelector.StorageTooltip".Translate(
                    storageLabel,
                    $"{usedStacks}/{maxStacks}"
                );

                tooltip += "\n\n" + "ZB333ZB.StorageSelector.StoredItems".Translate() + ":";

                var storedItems = new Dictionary<ThingDef, int>();
                var positions = new List<IntVec3>();

                if (storage is Building_Storage building)
                {
                    var size = building.def.size;
                    var rot = building.Rotation;
                    var basePos = building.Position;

                    for (int x = 0; x < size.x; x++)
                    {
                        for (int z = 0; z < size.z; z++)
                        {
                            var offset = new IntVec3(x, 0, z).RotatedBy(rot);
                            positions.Add(basePos + offset);
                        }
                    }
                }
                else if (storage is Zone_Stockpile zoneStockpile)
                {
                    positions.AddRange(zoneStockpile.cells);
                }

                foreach (var pos in positions)
                {
                    var map = storage is Thing t ? t.Map : (storage as Zone_Stockpile)?.Map;
                    if (map == null) continue;

                    var thingsAtPos = map.thingGrid.ThingsListAtFast(pos);
                    foreach (var thing in thingsAtPos)
                    {
                        if (thing.def.category != ThingCategory.Item) continue;

                        if (!storedItems.ContainsKey(thing.def))
                            storedItems[thing.def] = 0;
                        storedItems[thing.def] += thing.stackCount;
                    }
                }

                if (!storedItems.Any())
                {
                    tooltip += $"\n  - {"ZB333ZB.StorageSelector.Nothing".Translate()}";
                }
                else
                {
                    foreach (var item in storedItems)
                    {
                        tooltip += $"\n  - {item.Key.label} (x{item.Value})";
                    }
                }

                return tooltip;
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Error in GetStorageTooltip: {e}");
                return "";
            }
        }

        public static void UpdateBillStorageReferences()
        {
            try
            {
                var storage = ExtendedBillDataStorage.GetStorage();
                if (storage == null) return;

                var maps = Find.Maps;
                if (maps == null) return;

                foreach (var map in maps)
                {
                    if (map == null) continue;

                    var billGivers = map.listerBuildings.allBuildingsColonist
                        .OfType<IBillGiver>()
                        .Where(b => b.BillStack != null);

                    foreach (var billGiver in billGivers)
                    {
                        foreach (var bill in billGiver.BillStack.Bills.OfType<Bill_Production>())
                        {
                            var inputStorage = storage.GetInputStorage(bill);
                            var outputStorage = storage.GetOutputStorage(bill);

                            if (inputStorage != null && (!inputStorage.Spawned || !IsValidStorageBuilding(inputStorage)))
                            {
                                storage.SetInputStorage(bill, null);
                            }

                            if (outputStorage != null && (!outputStorage.Spawned || !IsValidStorageBuilding(outputStorage)))
                            {
                                storage.SetOutputStorage(bill, null);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Error in UpdateBillStorageReferences: {e}");
            }
        }
    }
}
