using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace StorageSelector
{
    [StaticConstructorOnStartup]
    public static class HarmonyPatches
    {
        private static readonly bool IsBWMActive = ModsConfig.ActiveModsInLoadOrder.Any(m =>
            m.PackageId.Equals("falconne.bwm", StringComparison.OrdinalIgnoreCase));

        static HarmonyPatches()
        {
            var harmony = new Harmony("ZB333ZB.StorageSelector");

            Log.Message("[StorageSelector] Starting ZB333ZB's Storage Selector patch initialization...");
            Log.Message($"[StorageSelector] Better Workbench Management (BWM) is {(IsBWMActive ? "active" : "not active")}");

            try
            {
                var methods = new[]
                {
                    new
                    {
                        Name = "TryFindBestBillIngredientsInSet",
                        Type = typeof(WorkGiver_DoBill),
                        Method = AccessTools.Method(typeof(WorkGiver_DoBill), "TryFindBestBillIngredientsInSet")
                    },
                    new
                    {
                        Name = "SetStoreMode",
                        Type = typeof(Bill_Production),
                        Method = AccessTools.Method(typeof(Bill_Production), "SetStoreMode")
                    },
                    new
                    {
                        Name = "FinishRecipeAndStartStoringProduct",
                        Type = typeof(Toils_Recipe),
                        Method = AccessTools.Method(typeof(Toils_Recipe), "FinishRecipeAndStartStoringProduct")
                    },
                    new
                    {
                        Name = "Notify_BillWorkStarted",
                        Type = typeof(Bill),
                        Method = AccessTools.Method(typeof(Bill), nameof(Bill.Notify_BillWorkStarted))
                    }
                };

                foreach (var methodInfo in methods)
                {
                    if (methodInfo.Method != null)
                    {
                        var parameters = methodInfo.Method.GetParameters();
                        Log.Message($"[StorageSelector] Found {methodInfo.Name} method in {methodInfo.Type.Name}:");
                        Log.Message($"[StorageSelector] - Return type: {methodInfo.Method.ReturnType.Name}");
                        Log.Message($"[StorageSelector] - Parameters: {string.Join(", ", parameters.Select(p => $"{p.ParameterType.Name} {p.Name}"))}");
                        Log.Message($"[StorageSelector] - Is Virtual: {methodInfo.Method.IsVirtual}");
                        Log.Message($"[StorageSelector] - Is Public: {methodInfo.Method.IsPublic}");
                    }
                    else
                    {
                        Log.Error($"[StorageSelector] Could not find method {methodInfo.Name} in {methodInfo.Type.Name}");
                    }
                }

                harmony.PatchAll(Assembly.GetExecutingAssembly());

                var patchedMethods = harmony.GetPatchedMethods().ToList();
                Log.Message($"[StorageSelector] Successfully patched {patchedMethods.Count} methods:");
                foreach (var method in patchedMethods)
                {
                    var info = Harmony.GetPatchInfo(method);
                    Log.Message($"[StorageSelector] - {method.DeclaringType?.Name}.{method.Name}:");

                    if (info.Prefixes.Any())
                    {
                        Log.Message($"[StorageSelector]   Prefixes ({info.Prefixes.Count}):");
                        foreach (var patch in info.Prefixes)
                        {
                            Log.Message($"[StorageSelector]    - {patch.owner}: {patch.PatchMethod.Name}");
                            var patchParams = patch.PatchMethod.GetParameters();
                            Log.Message($"[StorageSelector]      Parameters: {string.Join(", ", patchParams.Select(p => $"{p.ParameterType.Name} {p.Name}"))}");
                        }
                    }

                    if (info.Postfixes.Any())
                    {
                        Log.Message($"[StorageSelector]   Postfixes ({info.Postfixes.Count}):");
                        foreach (var patch in info.Postfixes)
                        {
                            Log.Message($"[StorageSelector]    - {patch.owner}: {patch.PatchMethod.Name}");
                            var patchParams = patch.PatchMethod.GetParameters();
                            Log.Message($"[StorageSelector]      Parameters: {string.Join(", ", patchParams.Select(p => $"{p.ParameterType.Name} {p.Name}"))}");
                        }
                    }
                }

                if (Current.Game?.Maps != null)
                {
                    foreach (var map in Current.Game.Maps)
                    {
                        var storageBuildings = map.listerBuildings.allBuildingsColonist
                            .Where(b => b is Building_Storage)
                            .Cast<Building_Storage>();

                        Log.Message($"[StorageSelector] Found {storageBuildings.Count()} storage buildings on map {map.Index}");
                        foreach (var storage in storageBuildings)
                        {
                            var slotGroup = storage.GetSlotGroup();
                            var cellCount = slotGroup?.CellsList?.Count ?? 0;
                            var maxStacks = StorageUtility.GetMaxStacks(storage);
                            var usedStacks = StorageUtility.GetUsedStacks(storage);

                            Log.Message($"[StorageSelector] Storage building: {storage.Label}" +
                                $"\n  - Valid Storage: {StorageUtility.IsValidStorageBuilding(storage)}" +
                                $"\n  - Cell Count: {cellCount}" +
                                $"\n  - Max Stacks: {maxStacks}" +
                                $"\n  - Used Stacks: {usedStacks}" +
                                $"\n  - Position: {storage.Position}" +
                                $"\n  - Storage Settings: {(storage.GetSlotGroup()?.Settings != null ? "Present" : "Missing")}" +
                                $"\n  - Reachable: {storage.Map.reachability.CanReach(storage.Position, storage.Position, PathEndMode.Touch, TraverseParms.For(TraverseMode.PassDoors))}");
                        }
                    }

                    var billStorage = ExtendedBillDataStorage.GetStorage();
                    if (billStorage != null)
                    {
                        foreach (var map in Current.Game.Maps)
                        {
                            var billGivers = map.listerBuildings.allBuildingsColonist
                                .OfType<IBillGiver>()
                                .Where(b => b.BillStack != null);

                            foreach (var billGiver in billGivers)
                            {
                                foreach (var bill in billGiver.BillStack)
                                {
                                    var inputStorage = billStorage.GetInputStorage(bill);
                                    var outputStorage = billStorage.GetOutputStorage(bill);

                                    if (inputStorage != null || outputStorage != null)
                                    {
                                        Log.Message($"[StorageSelector] Bill storage assignment:" +
                                            $"\n  - Bill: {bill.Label}" +
                                            $"\n  - Input Storage: {(inputStorage != null ? inputStorage.Label : "None")}" +
                                            $"\n  - Output Storage: {(outputStorage != null ? outputStorage.Label : "None")}");
                                    }
                                }
                            }
                        }
                    }
                }

                Log.Message("[StorageSelector] Initialization completed successfully");
            }
            catch (Exception e)
            {
                Log.Error($"[StorageSelector] Failed to initialize patches: {e}");

                if (e is HarmonyException he && he.InnerException != null)
                {
                    Log.Error($"[StorageSelector] Inner exception: {he.InnerException}");
                    if (he.InnerException.StackTrace != null)
                    {
                        Log.Error($"[StorageSelector] Stack trace: {he.InnerException.StackTrace}");
                    }
                }
            }
        }
    }
}
