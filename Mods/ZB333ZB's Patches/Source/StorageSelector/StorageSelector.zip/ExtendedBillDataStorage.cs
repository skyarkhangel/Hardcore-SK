using System.Collections.Generic;
using RimWorld;
using Verse;

namespace StorageSelector
{
    public class ExtendedBillDataStorage : GameComponent
    {
        private Dictionary<int, string> inputStorageThingIDs = new();
        private Dictionary<int, string> outputStorageThingIDs = new();

        public ExtendedBillDataStorage(Game game) : base() { }

        public override void ExposeData()
        {
            base.ExposeData();

            Scribe_Collections.Look(ref inputStorageThingIDs, "inputStorageThingIDs", LookMode.Value, LookMode.Value);
            Scribe_Collections.Look(ref outputStorageThingIDs, "outputStorageThingIDs", LookMode.Value, LookMode.Value);

            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                inputStorageThingIDs ??= new Dictionary<int, string>();
                outputStorageThingIDs ??= new Dictionary<int, string>();
            }
        }

        private Building_Storage RestoreBuildingReference(string thingID)
        {
            if (string.IsNullOrEmpty(thingID)) return null;

            foreach (var map in Current.Game.Maps)
            {
                var storageBuildings = map.listerBuildings.AllBuildingsColonistOfClass<Building_Storage>();
                foreach (var storage in storageBuildings)
                {
                    if (storage.ThingID == thingID)
                        return storage;
                }
            }
            return null;
        }

        public void SetInputStorage(Bill bill, Building_Storage storage)
        {
            if (bill == null) return;

            var billID = bill.GetHashCode();
            if (storage == null)
                inputStorageThingIDs.Remove(billID);
            else
                inputStorageThingIDs[billID] = storage.ThingID;
        }

        public void SetOutputStorage(Bill bill, Building_Storage storage)
        {
            if (bill == null) return;

            var billID = bill.GetHashCode();
            if (storage == null)
                outputStorageThingIDs.Remove(billID);
            else
                outputStorageThingIDs[billID] = storage.ThingID;
        }

        public Building_Storage GetInputStorage(Bill bill)
        {
            if (bill == null) return null;

            var billID = bill.GetHashCode();
            return inputStorageThingIDs.TryGetValue(billID, out var thingID) ?
                RestoreBuildingReference(thingID) : null;
        }

        public Building_Storage GetOutputStorage(Bill bill)
        {
            if (bill == null) return null;

            var billID = bill.GetHashCode();
            return outputStorageThingIDs.TryGetValue(billID, out var thingID) ?
                RestoreBuildingReference(thingID) : null;
        }

        public static ExtendedBillDataStorage GetStorage()
        {
            return Current.Game.GetComponent<ExtendedBillDataStorage>();
        }
    }
}
